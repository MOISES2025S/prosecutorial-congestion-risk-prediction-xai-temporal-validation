**Figure 1.** Methodological workflow: from data quality assessment to consensus feature selection.

**Figure 2.** Two-dimensional UMAP representation of the feature space of the training set (2019–2023).

**Figure 3.** Experimental design for model training and temporal validation.

**Figure 4.** Reliability diagram of the final model (LightGBM, τ = 0.46) on the 2025 test set.

**Figure 5.** Gain curves of the final model, the persistence baseline and a random order: share of at-risk combinations captured as a function of the share of records reviewed (2025 test set and January–September 2026).

**Figure 6.** Global feature importance of the final model according to mean absolute SHAP values (2025 test set; 20 leading features).

**Figure 7.** SHAP dependence of the feature pair with the highest mean SHAP interaction (2025 test set): contribution of the district × case type frequency, coloured by geographic location (ubigeo_pjfs).
